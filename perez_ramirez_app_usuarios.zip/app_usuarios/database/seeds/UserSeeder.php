<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert([
            'name'=>'Fernando Pérez',
            'email'=>'perez@gmail.com',
            'password'=> bcrypt('fernando2021'),
            'profession'=>'1',
            ]);

        DB::table('users')->insert([
            'name'=>'Stefani Vasquez',
            'email'=>'vasquez@gmail.com',
            'password'=> bcrypt('vazquez2021'),
            'profession'=>'2',
            ]);

        DB::table('users')->insert([
            'name'=>'Carlos Juárez',
            'email'=>'juarez@gmail.com',
            'password'=> bcrypt('juarez2021'),
            'profession'=>'3',
            ]);

        DB::table('users')->insert([
            'name'=>'Daniela Prado',
            'email'=>'prado@gmail.com',
            'password'=> bcrypt('prado2021'),
            'profession'=>'4',
            ]);

        DB::table('users')->insert([
            'name'=>'Andrés Gonzales',
            'email'=>'gonzalez@gmail.com',
            'password'=> bcrypt('gonzalez2021'),
            'profession'=>'5',
            ]);

        DB::table('users')->insert([
            'name'=>'Carlos Mónaco',
            'email'=>'monaco@gmail.com',
            'password'=> bcrypt('monaco2021'),
            'profession'=>'6',
            ]);

        DB::table('users')->insert([
            'name'=>'Alejandro Ramos',
            'email'=>'ramos@gmail.com',
            'password'=> bcrypt('ramos2021'),
            'profession'=>'7',
            ]);

        DB::table('users')->insert([
            'name'=>'Estela Cáder',
            'email'=>'cader@gmail.com',
            'password'=> bcrypt('cader2021'),
            'profession'=>'8',
            ]);

        DB::table('users')->insert([
            'name'=>'Pedro López',
            'email'=>'lopez@gmail.com',
            'password'=> bcrypt('lopez2021'),
            'profession'=>'9',
            ]);

        DB::table('users')->insert([
            'name'=>'Yovani Martínez',
            'email'=>'martinez@gmail.com',
            'password'=> bcrypt('martinez2021'),
            'profession'=>'10',
            ]);

        DB::table('users')->insert([
            'name'=>'Flor Cisneros',
            'email'=>'cisneros@gmail.com',
            'password'=> bcrypt('cisneros2021'),
            'profession'=>'2',
            ]);
    

    
    }
}
