<?php

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;

class ProfessionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::statement('SET FOREIGN_KEY_CHECKS = 0');
        DB::table('professions')->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS = 1');

        DB::table('professions')->insert([
            'title'=>'Desarrollador Back-end',
            ]);

        DB::table('professions')->insert([
            'title'=>'Desarrollador Front-end',
            ]);

        DB::table('professions')->insert([
            'title'=>'Full developer',
            ]);

        DB::table('professions')->insert([
            'title'=>'Analista de base de datos',
            ]);

        DB::table('professions')->insert([
            'title'=>'Analista Programador.',
            ]);

        DB::table('professions')->insert([
            'title'=>'Diseñador Gráfico',
            ]);

        DB::table('professions')->insert([
            'title'=>'Analista de sistemas',
            ]);

        DB::table('professions')->insert([
            'title'=>'Auditor de sistemas',
            ]);

        DB::table('professions')->insert([
            'title'=>'Administrador de redes',
            ]);

        DB::table('professions')->insert([
            'title'=>'Administrador de centros de cómputo',
            ]);

        DB::table('professions')->insert([
            'title'=>'Laboratorio de informática',
            ]);
    }
}
