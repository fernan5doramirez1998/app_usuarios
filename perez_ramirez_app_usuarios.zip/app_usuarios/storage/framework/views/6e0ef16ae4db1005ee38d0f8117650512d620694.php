<?php $__env->startSection('title',"Detalle del user {$id}"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Mostrar usuarios <?php echo e($id); ?></h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>