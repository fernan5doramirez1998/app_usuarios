@extends('layout')
@section('title',"Detalle del user {$id}")

@section('content')
    <h1>Mostrar usuarios {{ $id}}</h1>

@endsection

