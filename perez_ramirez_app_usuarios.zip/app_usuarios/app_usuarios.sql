-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-09-2021 a las 22:05:03
-- Versión del servidor: 5.7.33-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `app_usuarios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2021_09_05_043820_create_professions_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `professions`
--

CREATE TABLE `professions` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `professions`
--

INSERT INTO `professions` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Desarrollador Back-end', NULL, NULL),
(2, 'Desarrollador Front-end', NULL, NULL),
(3, 'Full developer', NULL, NULL),
(4, 'Analista de base de datos', NULL, NULL),
(5, 'Analista Programador.', NULL, NULL),
(6, 'Diseñador Gráfico', NULL, NULL),
(7, 'Analista de sistemas', NULL, NULL),
(8, 'Auditor de sistemas', NULL, NULL),
(9, 'Administrador de redes', NULL, NULL),
(10, 'Administrador de centros de cómputo', NULL, NULL),
(11, 'Laboratorio de informática', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profession` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `profession`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, 'Fernando Pérez', 'perez@gmail.com', '1', '$2y$10$3PgvnkcY0RzPi7oXBRbrAezA4EFLPlo7abJmJQJIIo0BjZ96s4cqC', NULL, NULL, NULL),
(7, 'Stefani Vasquez', 'vasquez@gmail.com', '2', '$2y$10$8rRBsGKVaVDakWue62cb5egAdUp4fnUAbXbIkCGkvJRyeWYm6kFAm', NULL, NULL, NULL),
(8, 'Carlos Juárez', 'juarez@gmail.com', '3', '$2y$10$aZVmmsVdJXr3wrMIKw/QNO2KL0s9t3sMIFDyMIeArlXdMg7Ya71Te', NULL, NULL, NULL),
(9, 'Daniela Prado', 'prado@gmail.com', '4', '$2y$10$jk9YTfVNlh6.NUieFZFqe.ljnOlQGtEMl7MPerQkn4GIkjHA70neG', NULL, NULL, NULL),
(10, 'Andrés Gonzales', 'gonzalez@gmail.com', '5', '$2y$10$cMIqTcN0DbEQ/7H2txXU/OHpjdzSpsfY7JpSCuxRNGuqB14CQ4WlG', NULL, NULL, NULL),
(11, 'Carlos Mónaco', 'monaco@gmail.com', '6', '$2y$10$QImd1VkyC.7pky6aLWtsmuCilmg/lzibMZc9W0.k38QgIfYdr7Rpm', NULL, NULL, NULL),
(12, 'Alejandro Ramos', 'ramos@gmail.com', '7', '$2y$10$Mhr5408vtGWuPBN1R7wpb.SgmEUokENuXinvmyXyKuSZpnERynm7S', NULL, NULL, NULL),
(13, 'Estela Cáder', 'cader@gmail.com', '8', '$2y$10$NpblfZqNZ/zGkVtEsk.n6OPbegXSigbyEk2B3vOtWzl6CwVJIMu8e', NULL, NULL, NULL),
(14, 'Pedro López', 'lopez@gmail.com', '9', '$2y$10$vwI6T5i2UKKGrGj8FhZG2.fT5Z1pvK0tuxa.Klt8BD7oWqTbGEGqK', NULL, NULL, NULL),
(15, 'Yovani Martínez', 'martinez@gmail.com', '10', '$2y$10$pxm6EUh3ot7JP.4X86JIm.kjiyaaFztr2gUS53jYF4uaZlyZBAmtm', NULL, NULL, NULL),
(16, 'Flor Cisneros', 'cisneros@gmail.com', '2', '$2y$10$YusJ13mYuI6tTtQsIBN02eX3/ZeBGVz8ojfAGjdkQOo5EfidYU49.', NULL, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `professions`
--
ALTER TABLE `professions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `professions`
--
ALTER TABLE `professions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
